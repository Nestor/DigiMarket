<?php 
require("../core/init.php");
?>
<!-- 
	Files made up of HTML wont be commented because I cant be bothered to.
	404 Comment not found
-->
<head>
	<title><?php echo MARKET_NAME; ?> | Home</title>
</head>

<h1>Electric Market</h1>
<h2>Under Development - Back-End being done</h2>
<h4>(Front-End will be done after the Back-End)</h4>
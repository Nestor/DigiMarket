class Upload {
	function fileUpload() { // Values will be inserted when the main chunk of code is in
	
	}

	function picUpload() { // Values will be inserted when the main chunk of code is in
	
	}
}